We did all of our git usage on the github website itself just for
ease of teamwork. Here is the link attached to prove the usage of git.
Note the usage of many branches, we did a few commits in those during the
course of the development.

https://github.com/OratorZA/Assignment1_60_CSC3002F

